$('#exampleModalLabel').on('shown.bs.modal', function () {
    $('#exampleModalLabel').trigger('focus')
})